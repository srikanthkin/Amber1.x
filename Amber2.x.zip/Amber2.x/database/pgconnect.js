const pg =  require('pg');


const config = {
    user:'postgres',
    database:'postgres',
    password:'chulesh_arkesh',
    host:'localhost',
    port:5432,
    max:10000,
    idleTimeoutMillis: 30000,
};

const pool = new pg.Pool(config);

pool.connect((err,result,done)=>{
    if(err){
        console.log('Postgres Sql Connection Failed');
    }
    console.log('Connection Established With Postgres SQL')
    done();
});


module.exports = pool;