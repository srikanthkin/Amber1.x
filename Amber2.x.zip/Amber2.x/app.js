const express = require('express');
const app = express();
const path = require("path");
const port = 3000;
const pool = require('./database/pgconnect');
const bodyParser = require("body-parser");


//View Engine
app.set('view engine','ejs');
app.set('views',path.join(__dirname,'views'));

//Body Parser middleware - Used to get req from the GUI fields
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({limit: '500mb',extended: false}));


/* Routes - Place where Business Logic is written - Application Layer */
const index = require('./routes/index.js')
const login = require('./routes/loginModule/login');

/* GUI Part of the Application */
app.use('/',index);
app.use('/loginModule/login',login);

app.listen(port,()=>{
    console.log('Amber 2.x Application Started');
    console.log('Amber 2.x is Live now on Port : ',port);
});