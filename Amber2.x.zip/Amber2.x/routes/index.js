/* This is the Main Index routing Page of the Application */

const express = require('express');
const app = express.Router();


app.get('/',(req,res)=>{
        res.render('loginModule/login');
});

module.exports = app;
