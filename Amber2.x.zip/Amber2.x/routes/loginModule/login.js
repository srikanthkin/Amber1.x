/* This is the Main Index routing Page of the Application */

const express = require('express');
const app = express.Router();
const pool = require('../../database/pgconnect');

app.get('/',(req,res)=>{
    res.render('loginModule/login');
});


// Post Method to Insert Data into Table 

app.post('/PostDataToDb',(req,res)=>{

    const EmpName = req.body.EmpName;
    console.log(EmpName);

    pool.query('insert into username (user_name) values ($1)',[EmpName],(err,res)=>{
        if(err){console.log('Error encountered in SQL ',err)};
    });

    res.redirect('/loginModule/login');
    /* You can use Redirect Method Here . I have Not Used because i have not developed next Page*/

});


module.exports = app;